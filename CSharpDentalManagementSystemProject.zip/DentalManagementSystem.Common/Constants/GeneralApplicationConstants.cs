﻿namespace DentalManagementSystem.Common.Constants
{
    public static class GeneralApplicationConstants
    {
        public const int ReleaseYear = 2023;
    }
}
